A Pen created at CodePen.io. You can find this one at https://codepen.io/derekjp/pen/avodwL.

 This SASS Mixin takes one parameter: font size. When the mixin is used in conjunction with media queries you can easily make intricate responsive typographical styles very quickly.