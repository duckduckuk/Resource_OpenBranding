var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) {return typeof obj;} : function (obj) {return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;};var _extends = Object.assign || function (target) {for (var i = 1; i < arguments.length; i++) {var source = arguments[i];for (var key in source) {if (Object.prototype.hasOwnProperty.call(source, key)) {target[key] = source[key];}}}return target;};function _defineProperty(obj, key, value) {if (key in obj) {Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true });} else {obj[key] = value;}return obj;} // Need to make moar arts so that you can switch 'em.

var Keys = {
  ARROW_RIGHT: 39,
  ARROW_LEFT: 37 };


var ActionTypes = {
  INIT: '@@simple-redux/INIT',
  NEXT: Symbol('art/NEXT'),
  PREVIOUS: Symbol('art/PREVIOUS') };


var artCanvas = document.getElementById('art-canvas');
var MAX_COUNT = 5;
var initialState = {
  selected: 0,
  arts: Array.from({ length: 50 }) };


var store = createStore(selectArtReducer, initialState);

window.addEventListener('keydown', function (event) {
  if (event.keyCode === Keys.ARROW_RIGHT) {
    store.dispatch({ type: ActionTypes.NEXT });
  }

  if (event.keyCode === Keys.ARROW_LEFT) {
    store.dispatch({ type: ActionTypes.PREVIOUS });
  }
});

store.subscribe(function () {
  var state = store.getState();
  console.log(state);
  selectArt(state);
});

function selectArt(_ref) {
  // artCanvas.style.transform = `translateX(${10 * selected}px)`
  var selected = _ref.selected;}

function selectArtReducer() {var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 0;var action = arguments[1];
  var MAX_COUNT = state.arts.length;

  switch (action.type) {
    case ActionTypes.NEXT:
      return _extends({},
      state, {
        selected: state.selected < MAX_COUNT ? state.selected + 1 : 0 });

    case ActionTypes.PREVIOUS:
      return _extends({},
      state, {
        selected: state.selected > 0 ? state.selected - 1 : MAX_COUNT });

    default:
      return state;}

}

function createStore(reducer, preloadedState, enhancer) {
  if (typeof preloadedState === 'function' && typeof enhancer === 'undefined') {
    enhancer = preloadedState;
    preloadedState = undefined;
  }

  if (typeof enhancer !== 'undefined') {
    if (typeof enhancer !== 'function') {
      throw new Error('Expected the enhancer to be a function');
    }

    return enhancer(createStore)(reducer, preloadedState);
  }

  if (typeof reducer !== 'function') {
    throw new Error('Expected the reducer to be a function');
  }

  var currentReducer = reducer;
  var currentState = preloadedState;
  var currentListeners = [];
  var nextListeners = currentListeners;
  var isDispatching = false;

  function ensureCanMutateNextListeners() {
    if (nextListeners === currentListeners) {
      nextListeners = currentListeners.slice();
    }
  }

  function getState() {
    return currentState;
  }

  function subscribe(listener) {
    if (typeof listener !== 'function') {
      throw new Error('Expected listener to be a function');
    }

    var isSubscribed = true;

    ensureCanMutateNextListeners();
    nextListeners.push(listener);

    return function unsubscribe() {
      if (!isSubscribed) {
        return;
      }

      isSubscribed = false;

      ensureCanMutateNextListeners();
      var index = nextListeners.indexOf(listener);
      nextListeners.splice(index, 1);
    };
  }

  function dispatch(action) {
    if (typeof action.type === 'undefined') {
      throw new Error('Actions may not have an undefined "type" property.');
    }

    if (isDispatching) {
      throw new Error('Reducers may not dispatch actions.');
    }

    try {
      isDispatching = true;
      currentState = currentReducer(currentState, action);
    } finally {
      isDispatching = false;
    }

    var listeners = currentListeners = nextListeners;
    for (var i = 0; i < listeners.length; ++i) {
      var listener = listeners[i];
      listener();
    }

    return action;
  }

  function replaceReducer(nextReducer) {
    if (typeof nextReducer !== 'function') {
      throw new Error('Expected the nextReducer to be a function');
    }

    currentReducer = nextReducer;
    dispatch({ type: ActionTypes.INIT });
  }

  function observable() {
    var outerSubscribe = subscribe;
    return _defineProperty({
      subscribe: function subscribe(observer) {
        if ((typeof observer === 'undefined' ? 'undefined' : _typeof(observer)) !== 'object') {
          throw new TypeError('Expected the observer to be an object');
        }

        function observeState() {
          if (observer.next) {
            observer.next(getState());
          }
        }

        observeState();
        var unsubscribe = outerSubscribe(observeState);
        return { unsubscribe: unsubscribe };
      } },

    Symbol.observable, function () {
      return this;
    });

  }

  dispatch({ type: ActionTypes.INIT });

  return _defineProperty({
    dispatch: dispatch,
    subscribe: subscribe,
    getState: getState,
    replaceReducer: replaceReducer },
  Symbol.observable, observable);

}