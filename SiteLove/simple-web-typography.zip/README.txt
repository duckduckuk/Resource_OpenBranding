A Pen created at CodePen.io. You can find this one at https://codepen.io/AdamBlum/pen/hnbGf.

 Beautiful web typography with just the basics. It creates a clear hierarchy using a variety of font weights, styles, and sizes. You can find this project on GitHub here: https://github.com/AdamBlumMusic/Web-Type