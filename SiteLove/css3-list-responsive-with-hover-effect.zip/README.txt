A Pen created at CodePen.io. You can find this one at https://codepen.io/JFarrow/pen/sDxhA.

 CSS3 List Responsive with Hover Effect