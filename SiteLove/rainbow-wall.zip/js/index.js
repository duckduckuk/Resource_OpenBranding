/*
The rainbow wall design is inspired from http://evaldasmix.deviantart.com/art/Color-Burn-Wall-188311235
*/