A Pen created at CodePen.io. You can find this one at https://codepen.io/ronniechong/pen/LEXWVw.

 Having a play with flexbox, viewport height and CSS3 transform. The colour design is inspired from http://evaldasmix.deviantart.com/art/Color-Burn-Wall-188311235