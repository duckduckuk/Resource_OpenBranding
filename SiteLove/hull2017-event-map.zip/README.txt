A Pen created at CodePen.io. You can find this one at https://codepen.io/regmtait/pen/GrPoqp.

 A fun demo for the CodePen meetup in Hull, Feb 20 2017.