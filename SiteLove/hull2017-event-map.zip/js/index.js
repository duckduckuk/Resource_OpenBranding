var locations = [
  ['POWER IN WOMAN / FABULOUS FELINES / COUM TRANSMISSIONS, Humber Street Gallery, 64 Humber Street, HU1 1TU', 53.7395148, -0.3357267, 14],
  ['HULL TRINITY HOUSE Escorted Tour, Hull Trinity House, Trinity House Lane. Hull, HU1 2JG', 53.7424341, -0.3348696, 13],
  ['JOSE LONG, Something Better, Früit, 62-63 Humber St, Hull, HU1 1TU', 53.7391893, -0.3366907, 12],
  ['HULLYWOOD ICONS EXHIBITION, HIP Gallery, Princes Quay Shopping Centre, Princes Dock Street, Hull, HU1 2PQ', 53.7421642, -0.3415205, 11],
  ['TANYA RAABE-WEBBER: PORTRAITS UNTOLD, Artlink, 87 Princes Avenue, Hull, Hull, HU5 3QP', 53.7545948, -0.3621733, 10],
  ['UNTITLED EXHIBITION, Union Mash Up, 22-24 Princes Avenue, Hull, HU5 3QA', 53.7537405, -0.3620759, 9],
  ['THE HULL PEOPLE\'S MEMORIAL EXHIBITION, Hull Remembers, 22 Whitefriargate, Hull, HU1 2EX', 53.7431733, -0.3388138, 8],
  ['BLADE, Queen Victoria Square, HU1 3RQ', 53.7437271, -0.3413198, 7],
  ['LINES OF THOUGHT – A British Museum Touring Exhibition, Brynmor Jones Library, University of Hull, Cottingham Road, Hull, HU6 7RX', 53.770990, -0.368844, 6],
  ['PIETRO LORENZETTI: SIENA TO HULL, A MASTERPIECE REVEALED, Ferens Art Gallery, Queen Victoria Square, Hull, HU1 3RA', 53.75562, -0.34655, 4],
  ['HULL CHARTERS, Hull History Centre, Worship Street, Hull, HU2 8BG', 53.7478675, -0.3374512, 3],
  ['BOWHEAD, Hull Maritime Museum, Queen Victoria Square, Hull, HU1 3DX', 53.743941, -0.3408923, 2],
  ['RE-MADE IN HULL, ScrapStore, Hull Play Resource Centre, Dairycoates Avenue, Hull, HU3 5DB', 53.7365732, -0.3758707, 1],
];
var map = new google.maps.Map(document.getElementById('map-hull'), {
  zoom: 13,
  center: new google.maps.LatLng(53.757,-0.3574),

  styles: [{
    "featureType": "all",
    "elementType": "all",
    "stylers": [{
      "visibility": "on"
    }]
  }, {
    "featureType": "all",
    "elementType": "geometry",
    "stylers": [{
      "visibility": "on"
    }, {
      "saturation": "42"
    }, {
      "lightness": "18"
    }, {
      "gamma": "5.61"
    }, {
      "weight": "1.92"
    }]
  }, {
    "featureType": "administrative",
    "elementType": "labels.text.fill",
    "stylers": [{
      "color": "#444444"
    }]
  }, {
    "featureType": "administrative.land_parcel",
    "elementType": "all",
    "stylers": [{
      "visibility": "on"
    }]
  }, {
    "featureType": "administrative.land_parcel",
    "elementType": "geometry",
    "stylers": [{
      "visibility": "on"
    }]
  }, {
    "featureType": "administrative.land_parcel",
    "elementType": "labels",
    "stylers": [{
      "visibility": "on"
    }]
  }, {
    "featureType": "landscape",
    "elementType": "all",
    "stylers": [{
      "color": "#ff0000"
    }, {
      "visibility": "on"
    }]
  }, {
    "featureType": "landscape",
    "elementType": "geometry.fill",
    "stylers": [{
      "visibility": "off"
    }]
  }, {
    "featureType": "landscape",
    "elementType": "geometry.stroke",
    "stylers": [{
      "visibility": "simplified"
    }]
  }, {
    "featureType": "landscape.man_made",
    "elementType": "geometry",
    "stylers": [{
      "saturation": "12"
    }]
  }, {
    "featureType": "landscape.natural.landcover",
    "elementType": "geometry",
    "stylers": [{
      "visibility": "on"
    }]
  }, {
    "featureType": "landscape.natural.landcover",
    "elementType": "labels",
    "stylers": [{
      "visibility": "on"
    }]
  }, {
    "featureType": "landscape.natural.landcover",
    "elementType": "labels.text.fill",
    "stylers": [{
      "visibility": "on"
    }]
  }, {
    "featureType": "landscape.natural.terrain",
    "elementType": "geometry",
    "stylers": [{
      "visibility": "on"
    }]
  }, {
    "featureType": "landscape.natural.terrain",
    "elementType": "geometry.fill",
    "stylers": [{
      "visibility": "on"
    }]
  }, {
    "featureType": "poi",
    "elementType": "all",
    "stylers": [{
      "visibility": "off"
    }]
  }, {
    "featureType": "poi.attraction",
    "elementType": "geometry.fill",
    "stylers": [{
      "visibility": "on"
    }]
  }, {
    "featureType": "poi.park",
    "elementType": "geometry.fill",
    "stylers": [{
      "visibility": "on"
    }]
  }, {
    "featureType": "poi.sports_complex",
    "elementType": "geometry",
    "stylers": [{
      "visibility": "off"
    }, {
      "saturation": "5"
    }]
  }, {
    "featureType": "poi.sports_complex",
    "elementType": "geometry.fill",
    "stylers": [{
      "visibility": "on"
    }]
  }, {
    "featureType": "poi.sports_complex",
    "elementType": "labels.text",
    "stylers": [{
      "visibility": "on"
    }]
  }, {
    "featureType": "road",
    "elementType": "all",
    "stylers": [{
      "saturation": -100
    }, {
      "lightness": 45
    }]
  }, {
    "featureType": "road.highway",
    "elementType": "all",
    "stylers": [{
      "visibility": "simplified"
    }]
  }, {
    "featureType": "road.arterial",
    "elementType": "labels.icon",
    "stylers": [{
      "visibility": "off"
    }]
  }, {
    "featureType": "transit",
    "elementType": "all",
    "stylers": [{
      "visibility": "off"
    }]
  }, {
    "featureType": "water",
    "elementType": "all",
    "stylers": [{
      "color": "#00C6F5"
    }, {
      "visibility": "on"
    }]
  }, {
    "featureType": "water",
    "elementType": "geometry.fill",
    "stylers": [{
      "visibility": "on"
    }]
  }],
  mapTypeId: google.maps.MapTypeId.ROADMAP
});
var infowindow = new google.maps.InfoWindow();
var HullLatLng = new google.maps.LatLng(53.7555715, -0.4171581);
var marker, i;
for (i = 0; i < locations.length; i++) {
  marker = new google.maps.Marker({
    position: new google.maps.LatLng(locations[i][1], locations[i][2]),
    map: map,
    icon: 'https://www.regmtait.co.uk/codepen/pointer.svg'
  });
  google.maps.event.addListener(marker, 'click', (function(marker, i) {
    return function() {
      infowindow.setContent(locations[i][0]);
      infowindow.open(map, marker);
    };
  })(marker, i));
}